<template>
	<div class="main-header" :class=" [ mainHeader ? 'v-main-header' : ''] " >

		<div class="mh-middle">
			<span class="timesize">{{currentTime}}</span>
		</div>




		<div class="mh-left">
			<div class="navigation" :class="[ourl == '/iot/dataBoard/index' ? 'navigation-left-active' : '']"  @click="openPic('/iot/dataBoard/index')">
				<span class="navitext">数据看板</span>
			</div>
			<div class="navigation" :class="[ourl == '/iot/dataBoard/equipmentmannage' ? 'navigation-left-active' : '']"  @click="openPic('/iot/dataBoard/equipmentmannage')">
				<span class="navitext">设备管理</span>
			</div>
			<div class="navigation" @click="openPic('/iot/maintenance/plan')">

				<span class="navitext">运维维保</span>
			</div>
		</div>
		<div class="mh-right">
			<div class="navigation navigation-right" @click="openPic('/iot/maintenance/emergency')">

				<span class="navitext">应急管理</span>
			</div>
			<div class="navigation navigation-right" @click="openPic('/iot/maintenance/warning')">

				<span class="navitext">告警管理</span>
			</div>
			<div class="navigation navigation-right" @click="openPic('/iot/maintenance/data')">

				<span class="navitext">数据管理</span>
			</div>
		</div>





		 <div class="header-second" v-if="dataBoard">
            <div class="navigation navigation-btn " @click="openPic('/iot/dataBoard/index')" :class="[ourl == '/iot/dataBoard/index' ? 'navigation-btn-actvie' : '']">

              <span class="header-secondtitle">数据概览</span>
            </div>
            <div class="navigation navigation-btn " @click="openPic('/iot/dataBoard/fault')" :class="[ourl == '/iot/dataBoard/fault' ? 'navigation-btn-actvie' : '']">

              <span class="header-secondtitle">故障分析</span>
            </div>
     <!--       <div class="navigation">
              <img class="titlebackimg" src="https://axure-file.lanhuapp.com/md5__1d6d0e063b1876d57b70b16b2791fa56.svg">
              <span class="header-secondtitle">能耗分析</span>
            </div> -->
            </div>














	</div>





</template>

<script lang="ts" setup>
	// import { ref,reactive,computed,readonly,watchEffect,watch } from 'vue'
	import {
		useRouter,
		useRoute
	} from 'vue-router'
	const $router = useRouter()
	const props = defineProps({
		headerShow: {
			type: Boolean,
			default: true,
		},
	});
	import {
		ref
	} from 'vue';

	let mainHeader = ref(false)
	let dataBoard = ref(false)
	let ourl = ref('')

	const openPic = (url) => {
		$router.push(url);
	}


	watch(() => $router.currentRoute.value.path, (toPath) => {
		//要执行的方法
		ourl.value = toPath
		console.log(toPath, "toPath");
		if(toPath.includes('iot/maintenance')){
			mainHeader.value = true
		}else{
			mainHeader.value = false
		}


		if(toPath.includes('iot/dataBoard/index') || toPath.includes('iot/dataBoard/fault')){
			dataBoard.value = true
		}else{
			dataBoard.value = false
		}






	}, {
		immediate: true,
		deep: true
	})


	function jumpToEquipment() {
		$router.push('/iot/dataBoard/equipmentmannage');
	}


	const currentTime = ref(new Date())

	const Time = () => {
		const now = new Date();
		const year = now.getFullYear(); // 年
		const month = now.getMonth() + 1; // 月（注意月份是从0开始的，需要加1）
		const date = now.getDate(); // 日
		const day = now.getDay(); // 星期（0表示星期日，1表示星期一，以此类推）
		let hour = now.getHours(); // 时
		let minute = now.getMinutes(); // 分
		let second = now.getSeconds(); // 秒

		// 格式化日期时间信息
		const weekDays = ["日", "一", "二", "三", "四", "五", "六"];
		hour = hour < 10 ? "0" + hour : hour;
		minute = minute < 10 ? "0" + minute : minute;
		second = second < 10 ? "0" + second : second;
		const datetime = `${year}年${month}月${date}日 ${hour}:${minute}:${second}  星期${weekDays[day]}`;

		// 将格式化后的日期时间信息显示在页面上
		currentTime.value = datetime;
	}
	Time()

	setInterval(() => {
		Time()
	}, 1000)
</script>

<style lang="less" scoped>
	.main-header {
		color: #fff;
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: relative;
		width: 100%;
	}
	.v-main-header{
		height: 100px;
		padding-bottom: 40px;
	}

	.mh-left {
		display: flex;
		align-items: center;
		position: absolute;
		top: 44px;
	}

	.mh-right {
		display: flex;
		align-items: center;
		position: absolute;
		right: 0;
		top: 44px;
	}

	.mh-middle {
		// text-align: center;
		// font-size: 32px;
		// position: absolute;
		// left: 50%;
		// transform: translateX(-50%);
		// font-weight: 700;
		width: 100%;
		height: 88px;
		background: url(img/header.png) no-repeat;
		background-size: 100%;
	}

	.navigation {
		position: relative;
		cursor: pointer;
		width: 174px;
		height: 55px;
		display: flex;
		background: url(img/tab_left.png) no-repeat;
		background-size: contain;

	}
	.navigation-right{
		background: url(img/tab_right.png) no-repeat;
		background-size: contain;
	}

	.navigation-left-active{
		background: url(./img/tab_left_active.png) no-repeat;
		background-size: contain;
	}

	.navigation-btn{
		width: 182px;
		height: 40px;
		margin-left: 20px;
		background: url(img/tab_left_child.png) no-repeat;
		background-size: contain;
	}
	.navigation-btn-actvie{
		width: 182px;
		height: 40px;
		margin-left: 20px;
		background: url(./img/tab_left_child_active.png) no-repeat;
		background-size: contain;
	}

	.timesize {
		font-size: 20px;
		position: absolute;
		right: 20px;
		font-size: 16px;
		color: #F8FEFF;
		top: 12px;
	}

	.title {
		font-size: 24px;
		font-weight: bold;
		text-align: center;
		flex: 1;
	}

	.navitext {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}

	.header-second {
		display: flex;
		justify-content: center;
		position: absolute;
		margin-top: 150px;
		left: 50%;
		transform: translateX(-50%);
	}

	.header-secondtitle {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		font-size: 14px;
	}

	.header-linecharts {
		width: 100%;
		margin-top: 30px;
		height: 60px;
	}

	.titlebackimg {
		width: 100%
	}

	.v-header-second {
		position: absolute;
		display: flex;
		top: 104px;
		left:40px
	}

	.v-header-second .v-navigation {
		width: 100px;
		height: 40px;
	}

	.v-header-secondtitle {
		font-size: 12px !important;

	}
</style>
