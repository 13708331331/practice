
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" d="M10 0c5.523 0 10 4.477 10 10s-4.477 10-10 10S0 15.523 0 10S4.477 0 10 0Zm0 1.395a8.605 8.605 0 1 0 0 17.21a8.605 8.605 0 0 0 0-17.21Zm4.922 5.188c.28.25.304.682.053.962l-4.909 5.488a.682.682 0 0 1-1.006.011L5.72 9.47a.682.682 0 0 1 .995-.931l2.832 3.03l4.412-4.932a.682.682 0 0 1 .963-.053Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwCircleCheckO'
}
</script>