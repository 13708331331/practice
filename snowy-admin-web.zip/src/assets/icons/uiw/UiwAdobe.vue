<template>
	<svg width="1em" height="1em" viewBox="0 0 20 20">
		<path
			fill="currentColor"
			fillRule="evenodd"
			d="M20 1v18.001L12.607 1H20ZM7.399 1L0 19.001V1h7.399Zm2.604 6.265L14.713 19h-3.086l-1.41-3.419H6.77l3.233-8.316Z"
		></path>
	</svg>
</template>

<script>
	export default {
		name: 'UiwAdobe'
	}
</script>
