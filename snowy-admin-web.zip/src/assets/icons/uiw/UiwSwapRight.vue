
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" fillRule="evenodd" d="M17.625 12.08H.7c-.176 0-.7.092-.7.71s.524.71.7.71h18.599c.406 0 .701-.287.701-.71a.665.665 0 0 0-.164-.453a4.428 4.428 0 0 0-.173-.187L14.34 6.68c-.348-.278-.668-.27-.96.025c-.292.294-.311.61-.058.95l4.304 4.425Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwSwapRight'
}
</script>