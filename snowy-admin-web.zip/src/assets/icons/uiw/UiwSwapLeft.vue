
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" d="M2.64 11.917h16.591a.78.78 0 0 1 .769.792a.78.78 0 0 1-.769.791H.771c-.688 0-1.03-.857-.541-1.354L5.549 6.73a.754.754 0 0 1 1.087.006a.808.808 0 0 1-.005 1.119l-3.99 4.063Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwSwapLeft'
}
</script>