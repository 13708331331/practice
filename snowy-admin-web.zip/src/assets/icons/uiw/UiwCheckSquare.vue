
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" d="M18.182 0C19.186 0 20 .814 20 1.818v16.364A1.818 1.818 0 0 1 18.182 20H1.818A1.818 1.818 0 0 1 0 18.182V1.818C0 .814.814 0 1.818 0h16.364Zm-3.26 6.564a.682.682 0 0 0-.963.053L9.547 11.55L6.715 8.52a.682.682 0 0 0-.996.931l3.34 3.575a.682.682 0 0 0 1.007-.01l4.91-5.489a.682.682 0 0 0-.054-.962Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwCheckSquare'
}
</script>