
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" fillRule="evenodd" d="m9.551.222l-7.82 7.696c-.306.416-.309.78-.008 1.091c.301.312.665.314 1.093.007l6.428-6.334V19.32c.041.453.319.68.833.681c.514.001.792-.226.833-.68l-.111-16.64l6.38 6.328c.415.321.78.321 1.092 0c.313-.32.334-.663.062-1.027l-7.7-7.76A.776.776 0 0 0 10.078 0a.674.674 0 0 0-.526.222Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwArrowUp'
}
</script>