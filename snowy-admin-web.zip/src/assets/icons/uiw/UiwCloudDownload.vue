
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" fillRule="evenodd" d="M11.5 2.5a4.499 4.499 0 0 1 4.492 4.77H16l-.001 1.227a4 4 0 0 1 3.996 3.799l.005.2a4 4 0 0 1-3.8 3.992l-.2.005h-.001L16 16.5H4a4.01 4.01 0 0 1-4-4.005a4 4 0 0 1 3.198-3.918a3 3 0 0 1 4.313-3.664A4.498 4.498 0 0 1 11.5 2.5Zm-.046 4h-2v4.922L7 11.42l3.454 4.076l3.464-4.073h-2.464V6.5Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwCloudDownload'
}
</script>