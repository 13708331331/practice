
<template>
  <svg width="1em" height="1em" viewBox="0 0 20 20"><path fill="currentColor" fillRule="evenodd" d="M20 10.873V20L8.479 18.537l.001-7.664H20Zm-13.12 0l-.001 7.461L0 17.461v-6.588h6.88ZM20 9.273H8.48l-.001-7.81L20 0v9.273ZM6.879 1.666l.001 7.607H0V2.539l6.879-.873Z"></path></svg>
</template>

<script>
export default {
  name: 'UiwWindows'
}
</script>