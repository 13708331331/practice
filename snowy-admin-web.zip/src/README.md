
### 插件:

| 序号    | 插件 | 版本 | 链接地址       | 用途 |
| ------- |--- | ----- | ------------- | ----- |
| 1       | sm-crypto | 0.3.11 | https://github.com/JuneAndGreen/sm-crypto    | 项目内部加解密 |
| 2       | snowy-form-design| 1.0.23 | https://www.npmjs.com/package/snowy-form-design | 工作流表单设计 |
| 3       | qrcode | 1.5.1 | https://fengyuanchen.github.io/vue-qrcode/ | 二维码生成 |
| 4       | g2plot | 2.4.10 | https://antv-g2plot.gitee.io/zh | G2Plot图表 |
| 5       | amap-jsapi-loader | 1.0.1 | https://lbs.amap.com/api/jsapi-v2/guide/abc/load | 高德地图 |
| 6       | highlight.js | 11.6.0 | https://highlightjs.org/ | 代码高亮 |
| 7       | @highlightjs/vue-plugin | 2.1.0 | https://highlightjs.org/ | 代码高亮支持Vue3的插件 |

