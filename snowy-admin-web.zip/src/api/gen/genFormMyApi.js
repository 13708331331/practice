import { baseRequest } from '@/utils/request'

const request = (url, ...arg) => baseRequest(`/api/webapp/gen/form/${url}`, ...arg)
/**
 * 我的流程
 *
 * @author yubaoshan
 * @date 2022-09-22 22:33:20
 */
export default {

	// 获取我可以发起的流程模型列表
	formMyModelList(data) {
		return request('myModelList', data, 'get')
	},
	// 表单保存
	formSave(data) {
		return request('saveData', data)
	},
	// 获取我发起的流程分页
	formMyPage(data) {
		return request('myPage', data, 'get')
	},
	// 撤回流程
	formRevoke(data) {
		return request('revoke', data)
	},
	// 获取表单详情
	formDetail(data) {
		return request('detail', data, 'get')
	}
}
