import { baseRequest } from '@/utils/request'

const request = (url, ...arg) => baseRequest(`/api/webapp/gen/formExm/` + url, ...arg)

/**
 * 表单实例Api接口管理器
 *
 * @author lihong
 * @date  2023/06/13 16:29
 **/
export default {
	// 获取表单实例分页
	genFormExmPage(data) {
		return request('page', data, 'get')
	},
	// 获取表单实例列表
	genFormExmList(data) {
		return request('list', data, 'get')
	},
	// 提交表单实例表单 edit为true时为编辑，默认为新增
	genFormExmSubmitForm(data, edit = false) {
		return request(edit ? 'add' : 'edit', data)
	},
	// 删除表单实例
	genFormExmDelete(data) {
		return request('delete', data)
	},
	// 获取表单实例详情
	genFormExmDetail(data) {
		return request('detail', data, 'get')
	}
}
