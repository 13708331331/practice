import { baseRequest } from '@/utils/request'

const request = (url, ...arg) => baseRequest(`/api/webapp/gen/travelRequest/` + url, ...arg)

/**
 * 出差申请Api接口管理器
 *
 * @author xusc
 * @date  2023/07/05 16:08
 **/
export default {
	// 获取出差申请分页
	travelRequestPage(data) {
		return request('page', data, 'get')
	},
	// 获取出差申请列表
	travelRequestList(data) {
		return request('list', data, 'get')
	},
	// 提交出差申请表单 edit为true时为编辑，默认为新增
	travelRequestSubmitForm(data, edit = false) {
		return request(edit ? 'add' : 'edit', data)
	},
	// 删除出差申请
	travelRequestDelete(data) {
		return request('delete', data)
	},
	// 获取出差申请详情
	travelRequestDetail(data) {
		return request('detail', data, 'get')
	},
	// 获取出差申请模板信息
	travelRequestTemplate(data) {
	return request('template', data, 'get')
}
}
