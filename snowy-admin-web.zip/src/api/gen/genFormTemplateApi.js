import { baseRequest } from '@/utils/request'

const request = (url, ...arg) => baseRequest(`/api/webapp/gen/formTemplate/` + url, ...arg)

/**
 * 表单模板Api接口管理器
 *
 * @author lihong
 * @date  2023/06/01 14:39
 **/
export default {
	// 获取表单模板分页
	genFormTemplatePage(data) {
		return request('page', data, 'get')
	},
	// 获取表单模板列表
	genFormTemplateList(data) {
		return request('allList', data, 'get')
	},
	// 提交表单模板表单 edit为true时为编辑，默认为新增
	genFormTemplateSubmitForm(data, edit = false) {
		return request(edit ? 'add' : 'edit', data)
	},
	// 删除表单模板
	genFormTemplateDelete(data) {
		return request('delete', data)
	},
	// 获取表单模板详情
	genFormTemplateDetail(data) {
		return request('detail', data, 'get')
	},
	// 停用模板
	formDisable(data) {
		return request('disableModel', data)
	},
	// 启用模板
	formEnable(data) {
		return request('enableModel', data)
	}
}
