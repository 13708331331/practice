<template></template>

<script>
	export default {
		name: 'PropNoticeInfo'
	}
</script>
