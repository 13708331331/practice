<template></template>

<script>
	export default {
		name: 'PropListenerInfo'
	}
</script>
