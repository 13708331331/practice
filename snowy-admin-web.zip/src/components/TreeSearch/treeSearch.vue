<template>
	<div>
		<a-input-search
			v-if="gData.length > 0"
			v-model:value="searchValue"
			style="margin-bottom: 8px"
			placeholder="Search"/>
		<a-tree
			v-if="gData.length > 0"
			:expanded-keys="expandedKeys"
			:checked-keys="checkedKeys"
			:selectable="selectable"
			:checkable="checkable"
			:auto-expand-parent="autoExpandParent"
			:tree-data="gData"
			:field-names="treeFieldNames"
			@select="treeSelect"
			@check="treeCheck"
			@expand="onExpand"
		>
			<template #title="{ name }">
				<span v-if="name.indexOf(searchValue) > -1">
				  {{ name.substr(0, name.indexOf(searchValue)) }}<span style="color: #f50">{{
						searchValue
					}}</span>{{ name.substr(name.indexOf(searchValue) + searchValue.length) }}
				</span>
				<span v-else>{{ name }}</span>
			</template>
		</a-tree>
		<a-empty v-else :image="Empty.PRESENTED_IMAGE_SIMPLE"/>
	</div>
</template>
<script setup name="treeSearch">

import {ref, watch} from 'vue';
import {Empty} from 'ant-design-vue'

const props = defineProps({
	treeData: {
		type: Array,
		default: () => [],
		required: false
	},
	fieldNames: {
		type: Object,
		default: () => new Object({children: 'children', title: 'name', key: 'id'}),
		required: false
	},
	expandedKeys: {
		type: Array,
		default: () => [],
		required: false
	},
	autoExpandParent: {
		type: Boolean,
		default: () => true,
		required: false
	},
	checkedKeys: {
		type: Array,
		default: () => [],
		required: false
	},
	selectable: {
		type: Boolean,
		default: () => true,
		required: false
	},
	checkable: {
		type: Boolean,
		default: () => false,
		required: false
	}
})

const emits = defineEmits(['select','check'])
const treeSelect = (selectedKeys) => {
	emits('select', selectedKeys)
}

const treeCheck = (checkedKeys) => {
	emits('check', checkedKeys)
}

const treeFieldNames = ref(props.fieldNames)

const dataList = [];
const dataIdList = [];
const generateList = data => {
	for (let i = 0; i < data.length; i++) {
		const node = data[i];
		dataList.push({
			id: node.id,
			name: node.name,
		});
		dataIdList.push(node.id);
		if (node.children) {
			generateList(node.children);
		}
	}
};
generateList(props.treeData);


const getParentKey = (id, tree) => {
	let parentKey;
	for (let i = 0; i < tree.length; i++) {
		const node = tree[i];
		if (node.children) {
			if (node.children.some(item => item.id === id)) {
				parentKey = node.id;
			} else if (getParentKey(id, node.children)) {
				parentKey = getParentKey(id, node.children);
			}
		}
	}
	return parentKey;
};


const autoExpandParent = ref(props.autoExpandParent);
const expandedKeys = ref(props.expandedKeys);
const searchValue = ref('');
const gData = ref(props.treeData);

const onExpand = id => {
	expandedKeys.value = id;
	autoExpandParent.value = false;
};

watch(searchValue, value => {
	expandedKeys.value = dataList.map(item => {
		if (item.name.indexOf(value) > -1) {
			return getParentKey(item.id, gData.value);
		}
		return null;
	}).filter((item, i, self) => item && self.indexOf(item) === i);
	searchValue.value = value;
	autoExpandParent.value = true;
});

</script>
