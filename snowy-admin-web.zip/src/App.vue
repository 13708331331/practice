<template>
	<a-config-provider :locale="locale">
		<router-view />
	</a-config-provider>
</template>

<script setup name="App">
	import i18n from '@/locales'
	import { globalStore } from '@/store'

	const store = globalStore()
	store.initTheme()
	const locale = i18n.global.messages[i18n.global.locale].lang
</script>
<style type="text/css">
	.v-base-name{
		font-weight: bold;
	}

	.work-box-par{
		margin: 10px;

	}
	.work-box{
		width: 100%;
		height: 100px;
		border-radius: 5px;
		background-color: #043756;
		/* box-shadow: 2px 1px 9px 3px #ccc; */
		display: flex;
		align-items: center;
		margin: 10px;
		cursor: pointer;
		justify-content: space-around;
		.fl{
			.fl-icon{
				width: 65px;
				height: 65px;
				border-radius: 50%;
				background-color: #fb6260;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			.fl-icon-1{
				background-color: #fb6260;
			}
			.fl-icon-2{
				background-color: #ffa94c;
			}
			.fl-icon-3{
				background-color: #aaaaaa;
			}
			.fl-icon-4{
				background-color: #51d351;
			}
			.fl-icon-5{
				background-color: #02a7f0;
			}



		}
		.fr{
			>p{
				margin-bottom: 0 !important;
			}
			>p:nth-child(2){
				font-weight: bold;
				font-size: 22px;
			}
		}
	}
	.v-snowy-form-build{
		margin: 15px 10px;
		.ant-input-affix-wrapper{
			border: none !important;
		}
	}

	.v-snowy-form-build input{
		pointer-events:none !important;
	}
	.v-snowy-form-build textarea{
		pointer-events: none !important;
		border: none;
		height: auto !important;
	}







	/* 名称 */
	.v-details-name{
		display: flex;
		align-items: center;
		position: relative;
		margin: 10px 0;
		.name{
			margin-left: 8px;
			font-size: 16px;
			font-weight: bold;
		}

	}
	.v-details-name ::after{
		display: block;
		content: '';
		width: 5px;
		height: 22px;
		position: absolute;
		background: var(--primary-color);
		top: 3px;
		left: 1px;
		margin-left: -1px;
	}
	.v-details-name-no-border .v-details-name ::after{
		display: none;
	}
	.main-content-wrapper{
		padding: 0 ;
	}

	#adminui-main{
		width: 100%;
		height: 100%;

	}

	#data-view{
		background-color: #030409;
	}
	.allheader{
		height:100px
	}

	.snowy-form-build-par .ant-form-item-control-input-content label{
		color: #fff !important;
		font-size: 16px !important;
		font-weight: bold;
		position: relative;
		    margin-left: 12px;
	}

	.snowy-form-build-par .ant-form-item-control-input-content label::after {
	    display: block;
	    content: '';
	    width: 5px;
	    height: 22px;
	    position: absolute;
	    background: var(--primary-color);
	    top: -2px;
	    left: -9px;
	    margin-left: -1px;
	}



	/* //大屏公共css */
	/* title */
	.lc1-header {
		width: 100%;
		height: 32px;
/* 		background: linear-gradient(90deg, rgba(23,172,255,0.67) 0%, rgba(23,172,255,0.18) 50%, rgba(23,172,255,0.1) 100%);
 */
		background:  url('../src/views/iot/dataBoard/img/lc1-header.png') no-repeat;
		background-size: auto;

		border-radius: 0px 0px 0px 0px;
		opacity: 1;
		position: relative;
		display: flex;
		align-items: center;
		margin-top: 8px;
		.lc1-header-left{
			position: absolute;
			z-index: 3;
		}
		.lc1-header-border{
			width: 100%;
			height: 10px;
			background: linear-gradient(90deg, rgba(23,172,255,0.2) 0%, rgba(23,172,255,0.1) 100%);
			border-radius: 0px 0px 0px 0px;
			opacity: 1;
			position: absolute;
			top: 50%;
			transform: translateY(-50%);

		}
	}
	/* 框 */
	.chart-box{
		background: rgba(2,35,77,0.95);
		border-radius: 0px 0px 0px 0px;
		opacity: 1;
		border: 1px solid rgba(0,240,255,0.2);
	}


	.maintain-message {
		width: 100%;
		margin-top: 10px;
		height: 100px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		background: linear-gradient(180deg, rgba(8,86,132,0.3) 0%, rgba(7,57,97,0.71) 46%, #062548 100%);
		border-radius: 5px;
		opacity: 1;
		border: 1px solid #A7F8FF;

	}

	.maintain-message-one {
		display: inline-block;
		width: 25%;
		height: 80%;
		position: relative;

		.message-border{
			position:absolute;
			display: block;
			content: '';
			width: 43px;
			height: 0px;
			opacity: 1;
			border: 1px solid;
			border-image: linear-gradient(90deg, rgba(114, 247, 255, 0), rgba(114, 247, 255, 0.5), rgba(114, 247, 255, 0)) 1 1;
			transform: rotate(270deg);
			top: 50%;
		}
		.message-border-left{
			left: -42px;
		}
		.message-border-right{
			right: -42px;
		}

	}

	/* 小标题 */
	.lc1-details-par{
		margin-top: 20px;
		.lc1-details {
			height: 22px;
			font-size: 14px;
			display: flex;
			justify-content: space-between;
			/* span {
				color: #096dd9;
				font-weight: bold;
				font-size: 35px;
				margin-left: 20px;
			} */
			.left{
				font-weight: 500;
				color: #fff;
				line-height: 16px;
				.name{
					margin-left: 5px;
				}
			}
			.right{
				font-weight: 500;
				color: #A7F8FF;
				line-height: 16px;
			}
		}

	}
	/* 进度条 */
	.progress-bar{
		.progress-box{
			display: flex;
			margin-top: 15px;

			.left{
				width: 32px;
				height: 32px;
				text-align: center;
				line-height: 32px;
				font-size: 16px;
				background: rgba(8,63,111,0.6);
				border-radius: 0px 0px 0px 0px;
				opacity: 1;
				margin-right: 10px;
				border-left: 2px solid  #CB313D;
			}
			.right{
				flex: 1;
				height: 32px;
				background: rgba(5,53,94,0.6);
				border-radius: 0px 0px 0px 0px;
				opacity: 1;
				position: relative;
				display: flex;
				align-items: center;
				padding-right: 15px;
				.icon{
					position: absolute;
					left: -3px;
					top: 50%;
					transform: translateY(-50%);
				}

				.progress-c{
					flex: 1;
					height: 8px;
					background: #02234C;
					border-radius: 10px 10px 10px 10px;
					opacity: 1;
					.progress-j{
						width: 80%;
						height: 8px;
						background: linear-gradient(270deg, #A7F8FF 0%, #17ACFF 100%);
						border-radius: 10px 10px 10px 10px;
						opacity: 1;
					}
				}

				.name{
					width: 60px;
					margin: 0 20px;
				}
				.data{
					width: 70px;
					font-size: 18px;
					color: #FED66F;
					text-align: right;
				}

			}
		}

	}
	/* 表格card */
	.table-wrapper{
		padding: 30px 20px;
		background: rgba(2,35,77,1);
		border-radius: 5px 5px 5px 5px;
		opacity: 1;
		border: 1px solid rgba(0,240,255,0.2);
	}

	.ant-table-tbody td {
	  background-color:  #02234C !important;
	}
	.table-striped td{
		 background-color: #063461 !important;
	}
	.ant-table-thead th{
		 background-color: #17507B !important;
	}


	.ant-picker-separator,.ant-picker-suffix,.ant-select-arrow,.ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon,.anticon.ant-input-clear-icon{
		color: #fff !important;
	}
	.ant-steps-item-icon{
		    border: 1px solid rgba(0, 0, 0, 0.75);
	}
	.ant-btn-dangerous.ant-btn-link[disabled], .ant-btn-dangerous.ant-btn-link[disabled]:hover, .ant-btn-dangerous.ant-btn-link[disabled]:focus, .ant-btn-dangerous.ant-btn-link[disabled]:active{
		color: rgba(255, 255, 255, 0.55) !important;
	}

	.ant-select-item-option-active {
	        background: #037bb4 !important;
	}

	.ant-modal-body{
		border: 2px solid #1591C6;
		background: #06294C;
	}
	.ant-modal-close-x{
		background: url('./views/iot/img/colse.png') no-repeat;
		 margin: 7px -11px;
	}
	.ant-modal-close-x .ant-modal-close-icon{
		display: none;
	}
/* 		.ant-select-item-option:focus {
		        background-color: transparent;
		        border: 0px !important;
		    }
 */








</style>
